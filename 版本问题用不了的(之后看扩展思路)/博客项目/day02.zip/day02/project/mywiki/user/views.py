import hashlib
import json
import time

import jwt
from django.http import HttpResponse, JsonResponse
from .models import *

from btoken.views import make_token

# Create your views here.
def users(request, username=None):

    if request.method == 'GET':
        #查询数据
        if username:
            #查询具体用户的数据
            try:
                user = UserProfile.objects.get(username=username)
            except Exception as e:
                user = None

            if not user:
                result = {'code':10108, 'error': 'User is not existed !'}
                return JsonResponse(result)
            #判断是否有查询字符串
            if request.GET.keys():
                #有查询字符串
                pass
            else:
                #无查询字符串
                result = {'code':200, 'username':username, 'data':{'nickname':user.nickname, 'email':user.email,'sign':user.sign, 'info': user.info,'avatar':''}}
                return JsonResponse(result)

    elif request.method == 'POST':
        #创建资源/ 注册用户
        # 注册用户成功后　签发 token[一天]
        #用户模块状态码　10100 开始　/ 200为正常返回
        #{'code': 200/101xx, 'data':xxx, 'error':xxx}
        #响应json字符串 return JsonResponse({})
        json_str = request.body
        if not json_str:
            result = {'code':10100, 'error':'Please give me data'}
            return JsonResponse(result)
        json_obj = json.loads(json_str)

        username = json_obj.get('username')
        email = json_obj.get('email')
        password_1 = json_obj.get('password_1')
        password_2 = json_obj.get('password_2')
        if not username:
            result = {'code':10101, 'error':'Please give me username'}
            return JsonResponse(result)
        if not email:
            result = {'code':10102, 'error':'Please give me email'}
            return JsonResponse(result)

        if not password_1 or not password_2:
            result = {'code':10103, 'error':'Please give me password'}
            return JsonResponse(result)

        if password_1 != password_2:
            result = {'code': 10104, 'error':'The password is not same!'}
            return JsonResponse(result)
        #检查当前用户名是否可用
        old_user = UserProfile.objects.filter(username=username)
        if old_user:
            result = {'code': 10105, 'error':'The username is already existed!'}
            return JsonResponse(result)
        #密码进行哈希　－　md5
        p_m = hashlib.md5()
        p_m.update(password_1.encode())

        #创建用户
        try:
            UserProfile.objects.create(username=username,password=p_m.hexdigest(),nickname=username, email=email)
        except Exception as e:
            print(e)
            result = {'code':10106, 'error':'The username is already used!'}
            return JsonResponse(result)

        #todo 生成token
        token = make_token(username)
        result = {'code':200, 'username':username, 'data':{'token':token.decode()}}
        return JsonResponse(result)

    return HttpResponse('test user')
